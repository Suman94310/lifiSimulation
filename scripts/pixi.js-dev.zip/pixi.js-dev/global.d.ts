declare module '*.frag' {
    const value: string;

    export default value;
}

declare module '*.vert' {
    const value: string;

    export default value;
}

declare module 'es6-promise-polyfill'
declare module '@lerna/project'
declare module '@lerna/batch-packages'
declare module '@lerna/filter-packages'
