declare namespace GlobalMixins
{
    // eslint-disable-next-line @typescript-eslint/no-empty-interface
    interface Mesh
    {

    }

    // eslint-disable-next-line @typescript-eslint/no-empty-interface
    interface MeshMaterial
    {

    }
}
