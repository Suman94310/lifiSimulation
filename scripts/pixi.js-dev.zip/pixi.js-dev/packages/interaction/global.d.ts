declare namespace GlobalMixins
{
    // eslint-disable-next-line @typescript-eslint/no-empty-interface
    interface DisplayObject extends Partial<import('@pixi/interaction').InteractiveTarget>
    {

    }
}
