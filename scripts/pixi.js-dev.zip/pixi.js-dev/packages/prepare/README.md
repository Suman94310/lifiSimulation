# @pixi/prepare

## Installation

```bash
npm install @pixi/prepare
```

## Usage

```js
import { Prepare } from '@pixi/canvas-prepare';
import { Renderer } from '@pixi/core';

Renderer.registerPlugin('prepare', Prepare);
```