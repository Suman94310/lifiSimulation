# @pixi/graphics

## Installation

```bash
npm install @pixi/graphics
```

## Usage

```js
import { Graphics } from '@pixi/graphics';

const shapes = new Graphics();
```
